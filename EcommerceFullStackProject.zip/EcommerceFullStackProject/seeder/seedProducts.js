require('dotenv').config({ path: require('path').join(__dirname, '../.env') })
const mongoose = require('mongoose')
const Product = require('../models/product')

const products = [
  // Electronics
  {
    name: 'Wireless Headphones',
    price: 129.99,
    category: 'Electronics',
    image:
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&h=500&fit=crop',
    description:
      'Premium noise-cancelling wireless headphones with 30-hour battery life',
    stock: 45,
    inStock: true,
  },
  {
    name: 'Smart Watch',
    price: 299.99,
    category: 'Electronics',
    image:
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop',
    description:
      'Advanced smartwatch with fitness tracking and heart rate monitor',
    stock: 32,
    inStock: true,
  },
  {
    name: 'USB-C Cable',
    price: 12.99,
    category: 'Electronics',
    image:
      'https://images.unsplash.com/photo-1625948515291-69613efd103f?w=500&h=500&fit=crop',
    description: 'Fast charging USB-C cable, 6ft length',
    stock: 150,
    inStock: true,
  },
  {
    name: 'Portable Speaker',
    price: 79.99,
    category: 'Electronics',
    image:
      'https://images.unsplash.com/photo-1589003077984-894e133814c9?w=500&h=500&fit=crop',
    description: 'Waterproof Bluetooth speaker with 360° sound',
    stock: 28,
    inStock: true,
  },
  {
    name: '4K Webcam',
    price: 159.99,
    category: 'Electronics',
    image:
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=500&h=500&fit=crop',
    description: 'Ultra HD 4K webcam for streaming and video calls',
    stock: 18,
    inStock: true,
  },

  // Clothing
  {
    name: 'Cotton T-Shirt',
    price: 24.99,
    category: 'Clothing',
    image:
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
    description: '100% premium cotton t-shirt, available in multiple colors',
    stock: 85,
    inStock: true,
  },
  {
    name: 'Denim Jeans',
    price: 59.99,
    category: 'Clothing',
    image:
      'https://images.unsplash.com/photo-1542272604-787c62d465d1?w=500&h=500&fit=crop',
    description: 'Classic blue denim jeans, comfortable fit',
    stock: 62,
    inStock: true,
  },
  {
    name: 'Casual Hoodie',
    price: 49.99,
    category: 'Clothing',
    image:
      'https://images.unsplash.com/photo-1556821552-5c0a8c4ea2a3?w=500&h=500&fit=crop',
    description: 'Soft fleece hoodie perfect for any season',
    stock: 44,
    inStock: true,
  },
  {
    name: 'Running Shoes',
    price: 89.99,
    category: 'Clothing',
    image:
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&h=500&fit=crop',
    description: 'Professional running shoes with cushioned sole',
    stock: 56,
    inStock: true,
  },
  {
    name: 'Winter Jacket',
    price: 129.99,
    category: 'Clothing',
    image:
      'https://images.unsplash.com/photo-1539533057440-7814a60d1581?w=500&h=500&fit=crop',
    description: 'Warm waterproof winter jacket',
    stock: 35,
    inStock: true,
  },

  // Accessories
  {
    name: 'Leather Wallet',
    price: 34.99,
    category: 'Accessories',
    image:
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=500&h=500&fit=crop',
    description: 'Genuine leather bifold wallet with RFID protection',
    stock: 72,
    inStock: true,
  },
  {
    name: 'Sunglasses',
    price: 79.99,
    category: 'Accessories',
    image:
      'https://images.unsplash.com/photo-1510739901312-405aa671713e?w=500&h=500&fit=crop',
    description: 'UV protection polarized sunglasses',
    stock: 48,
    inStock: true,
  },
  {
    name: 'Baseball Cap',
    price: 19.99,
    category: 'Accessories',
    image:
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop',
    description: 'Classic baseball cap in various colors',
    stock: 94,
    inStock: true,
  },
  {
    name: 'Backpack',
    price: 64.99,
    category: 'Accessories',
    image:
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop',
    description: 'Durable 30L laptop backpack with USB port',
    stock: 38,
    inStock: true,
  },
  {
    name: 'Wrist Watch',
    price: 89.99,
    category: 'Accessories',
    image:
      'https://images.unsplash.com/photo-1523170335684-f7fe5aa591e8?w=500&h=500&fit=crop',
    description: 'Elegant stainless steel analog wristwatch',
    stock: 52,
    inStock: true,
  },
]

async function seedDatabase() {
  try {
    await mongoose.connect(
      process.env.MONGODB_URI || 'mongodb://localhost:27017/ecommerce',
    )
    console.log('MongoDB connected')

    await Product.deleteMany({})
    console.log('Previous products cleared')

    await Product.insertMany(products)
    console.log(`${products.length} products seeded successfully`)

    await mongoose.connection.close()
  } catch (err) {
    console.error('Seeding error:', err.message)
    process.exit(1)
  }
}

seedDatabase()
