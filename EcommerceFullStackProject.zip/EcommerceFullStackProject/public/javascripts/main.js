console.log('E-commerce app loaded')
